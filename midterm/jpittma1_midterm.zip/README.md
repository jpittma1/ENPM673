# ENPM673-Midterm
PMRO Program at UMD-CP Spring 2022

#ENPM673 Spring 2022
#Section 0101
#Jerry Pittman, Jr. UID: 117707120
#jpittma1@umd.edu
#MIDTERM Exam

#********************************************
# Requires the following in same folder to run:
# 1) Python code based on the given problem: "question1.py", "question2.py", "question3.py" and "question4.py"
# 2) "Q1image.png" for question 1
# 3) "Q2imageA.png" and "Q2imageB.png" for question 2
# 4) "Q4image.png" for question 4
#********************************************

# Function modules used: numpy, cv2, matplotlib.pyplot, math